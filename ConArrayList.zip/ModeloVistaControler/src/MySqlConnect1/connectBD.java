/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MySqlConnect1;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author pedro
 */
public class connectBD {

    private Vista v;
    
    public static ArrayList<Alumno> llamadaBD(){
    
        String cadena_tabla = "";
        String modo = "root";
        String contrasena = "admin";
        String puerto = "3306";
        ArrayList<Alumno> aux = null;
        
        try{
            Connection connec =  (Connection) DriverManager.getConnection("jdbc:mysql://localhost:"+puerto,modo,contrasena);
            aux = BaseDatosVer(connec,"alumnos");
            
        }catch (SQLException e){

           System.out.println(e.getMessage());
        }
        
        return aux;
    }
    public static ArrayList<Alumno> BaseDatosVer(Connection con,String n_bd) throws SQLException{
  
    Statement stmt = null;
    String query;
        query = "select DNI, nom_alum from alumnos.alumnos";
    String DNI = null;
    String nom_alum = null;
    String cadena_tabla = "";
    ArrayList<Alumno> aux;
        aux = new ArrayList();
    
    try {
            stmt = (Statement) con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Alumno a = new Alumno();
                DNI = rs.getString("DNI");
                a.setDNI(DNI);
                nom_alum = rs.getString("nom_alum");
                a.setNom_alum(nom_alum);
               // System.out.println("dni : " + a.getDNI() + " nom_alum " + a.getNom_alum());
                
                aux.add(a);
            }
        } catch (SQLException e ) {
            JDBCTutorialUtilities.printSQLException(e);
        } finally {
            if (stmt != null) { stmt.close(); }
        }
        return aux;
    }
}
