/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MySqlConnect1;

import java.util.ArrayList;


/**
 *
 * @author pedro
 */
public class Vista {
    
    protected ArrayList<Alumno> alumnosArrayList;
    private connectBD c;
    
    public Vista(){
    
        alumnosArrayList = new ArrayList();
        
    }
    public void printArrayList( ){
     
         //Empty es para saber si hay alumnos dentro del array y te devuelve un true o un false
         if(!alumnosArrayList.isEmpty()){
             System.out.println("Alumnos registrados : ");
             for(int i = 0;i < alumnosArrayList.size();i++)
                   System.out.println(alumnosArrayList.get(i).getDNI()+ "\t" + alumnosArrayList.get(i).getNom_alum());
             
         }else{
         
             System.out.println("No se encuentran alumnos registrados...");
         }
      
     }
    
    public void llamadaBD(){
        
          this.alumnosArrayList = connectBD.llamadaBD();
         
     }
    public static void main(String[] args) {
            
        Vista v = new Vista();
   
        v.llamadaBD();   
        v.printArrayList();
   
    }
    
}
